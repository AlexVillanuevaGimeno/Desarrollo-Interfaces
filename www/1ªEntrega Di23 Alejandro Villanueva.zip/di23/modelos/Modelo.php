<?php
    class Modelo{
        function __construct(){
            //constructior de la clase modelo
        }
    }
?>